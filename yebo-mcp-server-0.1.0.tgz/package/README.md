# @yebo/mcp-server

Reusable MCP (Model Context Protocol) server for Yebo product APIs.

Mount it on any Express app to expose your product's actions to the
Hiyebo orchestrator (and any other MCP client) over JSON-RPC 2.0, with
YeboID JWT validation built in.

```bash
npm install @yebo/mcp-server
```

## What this gives you

- **JSON-RPC 2.0 dispatcher** at `POST /mcp` implementing the MCP
  spec methods: `initialize`, `tools/list`, `tools/call`,
  `notifications/initialized`.
- **`defineTool()` builder** with type-safe handlers, scope-based
  authorization, and three auth modes (`required` / `optional` / `none`).
- **YeboID JWT validation** via `jose`'s `createRemoteJWKSet` — no
  per-request call to YeboID, key rotation handled automatically.
- **Result helpers** (`text`, `list`, `card`, `form`, `confirmation`,
  `error`) that produce both a plain-text fallback and a structured
  payload the Hiyebo chat frontend renders as rich UI.
- **Health + version endpoints** at `GET /mcp/health` and
  `GET /mcp/version` for monitoring.
- **Standard error envelopes** mapping every failure to a JSON-RPC
  error code: `UNAUTHORIZED` (-32001), `TOOL_NOT_FOUND` (-32003),
  `INSUFFICIENT_SCOPE` (-32005), etc.

## Quickstart

```ts
import express from 'express';
import { createMcpServer, defineTool, results } from '@yebo/mcp-server';

const searchJobs = defineTool({
  name: 'search_jobs',
  description: 'Find jobs matching a query.',
  inputSchema: {
    type: 'object',
    properties: {
      query:    { type: 'string' },
      location: { type: 'string' },
    },
    required: ['query'],
  },
  auth: 'required',          // 'required' (default) | 'optional' | 'none'
  scopes: ['jobs:read'],
  async handler(args, ctx) {
    const jobs = await db.searchJobs(args);
    return results.list({
      title: `${jobs.length} jobs found`,
      items: jobs.map((j) => ({
        id: j.id,
        title: j.title,
        subtitle: `${j.company} • ${j.location}`,
        actions: [
          results.action('Apply', 'apply_to_job', { args: { jobId: j.id } }),
        ],
      })),
    });
  },
});

const app = express();
app.use(express.json());

app.use('/mcp', createMcpServer({
  server: { name: 'yebojobs', version: '1.0.0' },
  auth: {
    jwksUri: 'https://api.yeboid.com/.well-known/jwks.json',
    issuer:  'https://api.yeboid.com',
  },
  tools: [searchJobs],
}));

app.listen(3000);
```

That's it. Your product now exposes a fully MCP-compliant `/mcp`
endpoint that the orchestrator can `tools/list` and `tools/call`.

## Auth modes

| Mode | Bearer required? | Fallback if token bad |
|---|---|---|
| `required` (default) | yes | reject with `UNAUTHORIZED` |
| `optional` | no — but validated if present | run unauthenticated |
| `none` | never checked | always run |

Use `none` only for genuinely public catalogue endpoints (e.g. "list
public products"). Use `optional` for tools that work for guests but
return richer data for logged-in users (e.g. search). Use `required`
for everything else — that's the safe default.

Per-tool **scope** requirements add fine-grained authorization on top
of the auth mode:

```ts
defineTool({
  name: 'post_job',
  // ...
  auth: 'required',
  scopes: ['jobs:write', 'employer'],
  // ...
});
```

Tokens missing any of those scopes get `INSUFFICIENT_SCOPE` (-32005).

## Result helpers

Every helper returns a `ToolCallResult` with both an MCP-spec
`content` array (plain-text fallback) and a Yebo-extension `structured`
payload the Hiyebo chat frontend renders as a UI component.

```ts
results.text('Done!')

results.list({
  title: '3 results',
  items: [{ id: 'a', title: 'First', subtitle: 'subtitle' }],
})

results.card({
  title: 'Senior React Engineer',
  subtitle: 'Acme Corp · Lagos',
  fields: [
    { label: 'Salary', value: '$80k–120k' },
    { label: 'Type',   value: 'Full-time' },
  ],
  actions: [results.action('Apply', 'apply_to_job', { args: { id: 'job_42' } })],
})

results.form({
  title: 'Post a job',
  fields: [
    { name: 'title',    label: 'Title',    kind: 'text', required: true },
    { name: 'salary',   label: 'Salary',   kind: 'number' },
    { name: 'location', label: 'Location', kind: 'text' },
  ],
  submitIntent: 'post_job',
})

results.confirmation({
  title: 'Send 1,200 SMS messages?',
  body:  'Cost: 240 credits. This cannot be undone.',
  confirmIntent: 'send_bulk',
  confirmArgs: { campaignId: 'c_42' },
})

results.error('Listing not found')   // user-visible failure
```

For protocol-level failures (auth, malformed request, internal panic),
**throw** an Error from your handler — the dispatcher will return a
JSON-RPC error envelope automatically.

## Tool context

Every handler receives a `(args, ctx)` pair. The context gives you:

- `ctx.auth` — verified caller (`userId`, `name`, `phone`, `email`,
  `scopes`, `accessToken`). Undefined for `auth: 'none'` tools or
  unauthenticated `auth: 'optional'` tools.
- `ctx.requestId` — JSON-RPC request id, useful for logging.
- `ctx.rawRequest` — Express request, escape hatch for headers/IP.

## Wire format

`POST /mcp` accepts JSON-RPC 2.0 envelopes:

```bash
curl -X POST https://your-api.example.com/mcp \
  -H 'Content-Type: application/json' \
  -H 'Authorization: Bearer <yeboid-access-token>' \
  -d '{
    "jsonrpc": "2.0",
    "id": 1,
    "method": "tools/call",
    "params": {
      "name": "search_jobs",
      "arguments": { "query": "react", "location": "lagos" }
    }
  }'
```

Supported methods:

| Method | Purpose |
|---|---|
| `initialize` | Protocol handshake — returns `protocolVersion` + `serverInfo` |
| `tools/list` | Return the registered tool catalog |
| `tools/call` | Dispatch to a tool handler |
| `notifications/initialized` | Spec-compliant ack (no-op) |

## Error codes

| Code | Constant | When |
|---|---|---|
| -32600 | `INVALID_REQUEST` | Malformed JSON-RPC envelope |
| -32601 | `METHOD_NOT_FOUND` | Unknown method |
| -32602 | `INVALID_PARAMS` | `tools/call` missing `name` |
| -32603 | `INTERNAL_ERROR` | Unexpected exception |
| -32001 | `UNAUTHORIZED` | Missing or invalid Bearer token |
| -32003 | `TOOL_NOT_FOUND` | Unknown tool name |
| -32004 | `TOOL_EXECUTION_ERROR` | Handler threw |
| -32005 | `INSUFFICIENT_SCOPE` | Token missing required scopes |

## Running the example

```bash
npm install
npm run build
npx tsx examples/minimal.ts
# in another shell:
curl http://localhost:4001/mcp/health
```

## Conventions

- Tool names are **snake_case** and unique within a server.
- Tool names are short imperative verbs: `search_jobs`, `post_job`,
  `my_applications`. Avoid `get_*` / `list_*` prefixes — the
  orchestrator's intent router works better with verbs.
- Every tool needs a clear `description` — this is what the LLM router
  reads to decide when to call it. Write it for the LLM, not for humans.
- Use `auth: 'required'` unless you have a specific reason not to.
- Use `results.*` helpers — never construct `ToolCallResult` by hand.

## Inside the package

```
src/
├── index.ts        # public exports
├── server.ts       # createMcpServer() + JSON-RPC dispatcher
├── define-tool.ts  # defineTool() + ToolRegistry
├── auth.ts         # JwksValidator (uses jose)
├── results.ts      # text / list / card / form / confirmation / error / action
└── types.ts        # JSON-RPC + MCP + structured-result types
```

## See also

- Rollout plan: `~/.claude/plans/steady-moseying-stallman.md`
- Hiyebo orchestrator: `companies/yebohub/CLAUDE.md`
- YeboID auth provider: `companies/yeboid/CLAUDE.md`
- MCP spec: <https://spec.modelcontextprotocol.io/>
